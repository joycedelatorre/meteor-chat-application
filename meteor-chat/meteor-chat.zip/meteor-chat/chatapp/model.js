/**
* Models
*/
Messages = new Meteor.Collection('messages');